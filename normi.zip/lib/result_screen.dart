import 'package:flutter/material.dart';
import 'package:pumpkin_app/main.dart';
import 'package:pumpkin_app/top_bar.dart';

class ResultScreen extends StatelessWidget {
  final Map<int, String> trueFalseAnswers;
  final Map<int, String> oneWordAnswers;
  final Map<int, List<String>> multipleChoiceAnswers;
  final Map<int, String> gapFillAnswers;
  final Map<String, Map<int, dynamic>> correctAnswers;

  const ResultScreen({
    super.key,
    required this.trueFalseAnswers,
    required this.oneWordAnswers,
    required this.multipleChoiceAnswers,
    required this.gapFillAnswers,
    required this.correctAnswers,
  });

  @override
  Widget build(BuildContext context) {
    // Преобразуем correctAnswers к строгим типам
    final trueFalseCorrect =
        Map<int, String>.from(correctAnswers['trueFalse']!);
    final oneWordCorrect = Map<int, String>.from(correctAnswers['oneWord']!);
    final multipleChoiceCorrect =
        Map<int, List<String>>.from(correctAnswers['multipleChoice']!);
    final gapFillCorrect = Map<int, String>.from(correctAnswers['gapFill']!);

    // Подсчет правильных ответов
    final trueFalseScore = _calculateScore(trueFalseAnswers, trueFalseCorrect);
    final oneWordScore = _calculateScore(oneWordAnswers, oneWordCorrect);
    final multipleChoiceScore = _calculateMultipleChoiceScore(
      multipleChoiceAnswers,
      multipleChoiceCorrect,
    );
    final gapFillScore = _calculateScore(gapFillAnswers, gapFillCorrect);

    final totalQuestions = trueFalseAnswers.length +
        oneWordAnswers.length +
        multipleChoiceAnswers.length +
        gapFillAnswers.length;

    final totalScore =
        trueFalseScore + oneWordScore + multipleChoiceScore + gapFillScore;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 50),
            const TopBar(), // Сохраняем верхнюю панель
            const SizedBox(height: 20),
            const Text(
              'Video Name',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 30),
            const Text(
              'Your Score',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            Center(
              child: Text(
                '$totalScore / $totalQuestions',
                style: const TextStyle(
                  fontSize: 50,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildResultSection(
                        'True/False', trueFalseAnswers, trueFalseCorrect),
                    _buildResultSection(
                        'One Word Answer', oneWordAnswers, oneWordCorrect),
                    _buildResultSection('Multiple Choice',
                        multipleChoiceAnswers, multipleChoiceCorrect),
                    _buildResultSection(
                        'Gap Fill', gapFillAnswers, gapFillCorrect),
                  ],
                ),
              ),
            ),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  // Навигация на главный экран, заменяя текущий экран
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            const MainScreen()), // Замените на ваш главный экран
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color.fromRGBO(235, 103, 27, 1),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25.0),
                  ),
                ),
                child: const Text(
                  'Restart with new link',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 50), // Отступ снизу
          ],
        ),
      ),
    );
  }

  int _calculateScore(
      Map<int, String> userAnswers, Map<int, String> correctAnswers) {
    int score = 0;
    userAnswers.forEach((index, answer) {
      if (correctAnswers[index] == answer) {
        score++;
      }
    });
    return score;
  }

  int _calculateMultipleChoiceScore(Map<int, List<String>> userAnswers,
      Map<int, List<String>> correctAnswers) {
    int score = 0;
    userAnswers.forEach((index, answers) {
      if (Set.from(correctAnswers[index] ?? []).containsAll(answers) &&
          Set.from(answers).containsAll(correctAnswers[index]!)) {
        score++;
      }
    });
    return score;
  }

  Widget _buildResultSection(String title, Map<int, dynamic> userAnswers,
      Map<int, dynamic> correctAnswers) {
    // Пропустить секцию, если нет данных
    if (userAnswers.isEmpty || correctAnswers.isEmpty) {
      return const SizedBox.shrink(); // Возвращает пустой виджет
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        ...userAnswers.keys.map((index) {
          final userAnswer = userAnswers[index];
          final correctAnswer = correctAnswers[index];
          final isCorrect = userAnswer == correctAnswer ||
              (userAnswer is List &&
                  Set.from(userAnswer).containsAll(correctAnswer) &&
                  Set.from(correctAnswer).containsAll(userAnswer));

          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 5.0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 1,
                  child: Text(
                    'Q${index + 1}:',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Text(
                    'Your Answer: $userAnswer\nCorrect Answer: $correctAnswer',
                    style:
                        TextStyle(color: isCorrect ? Colors.green : Colors.red),
                  ),
                ),
              ],
            ),
          );
        }),
        const SizedBox(height: 20),
      ],
    );
  }
}
